package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import model.Utente;
import model.UtenteModelDAO;

@WebServlet("/UtenteControl")
public class UtenteControl extends HttpServlet {

	private static final long serialVersionUID = 1L;
	public static UtenteModelDAO model = new UtenteModelDAO();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String action = req.getParameter("action");
		
		try {
			if(action != null)
			{
				if(action.contentEquals("sigin")) {
					String email,pass;
					email = req.getParameter("email");
					pass = req.getParameter("password");
					
					String regEmail =  "/^[A-Za-z]+$/";
                    String regPassword =  "/^[A-Za-z]+$/";
                    Boolean validate  = true;
					
					if(!req.getParameter("email").matches(regEmail))
					{                     
						System.out.println("email dato corretto");             
					}
					else {validate=false;}       
					
					if(!req.getParameter("password").matches(regPassword)  && pass.length() >= 7 && pass.length() <= 12)  
					{   
						System.out.println("password dato corretto");                
					}
					else {validate=false;}
					
					
					
					if(validate==true) {
		                  System.out.println("tutti i campi sono giusti");
		              }else {
		                  RequestDispatcher view = req.getRequestDispatcher("Errore.jsp");
		                  HttpSession currentSession = req.getSession();
		                  currentSession.setAttribute("error", "Errore nel login");
		                  view.forward(req,resp);
		                    return;
		              }
					
					//se tutti i contorlli sono andati a buon fine profo ad effettuare il sigin
					
					
					
					
					
					
					Utente u = model.retriveUtenteByMail(email);
					if ( u == null)
					{
						
						getServletContext().setAttribute("errorEmail",  "errorEmail");

						resp.sendRedirect("jsp/Signin.jsp");
						
						return;
					}
					
					if(! u.getPass().equals(pass)  )
					{
				
						
						 getServletContext().setAttribute("errorPass",  "errorPass");

							resp.sendRedirect("jsp/Signin.jsp");
						
					}
					
					else {
						
					
					HttpSession oldSession = req.getSession();
					
					/*if( oldSession != null)
					{
					
						oldSession.invalidate();//invalida la sessione se esiste (sovrascrive)
					}*/
					
					HttpSession currentSession = req.getSession();//craa una sessione nuova
					if(u.isAdmin() )
						currentSession.setAttribute("user", u);
					else {
						currentSession.setAttribute("admin", true);
						currentSession.setAttribute("user", u);
						}
					
					currentSession.setMaxInactiveInterval(1*60);//5 min di sessione max
					
					RequestDispatcher view = req.getRequestDispatcher("index.jsp");
					view.forward(req, resp);
					return ;
				}
			}else if(action.contentEquals("registration")) {
				String email,pass,pass2,nome,cognome;
				email = req.getParameter("email");
				pass = req.getParameter("password");
				pass2 = req.getParameter("password2");
				nome = req.getParameter("nome");
				cognome = req.getParameter("cognome");
				System.out.println(email+","+nome+","+cognome);
				String regEmail =  "/^[A-Za-z@.]+$/";
                String regPassword =  "/^[A-Za-z]+$/";
                String regNome =  "/^[A-Za-z ]+$/";
                String regCognome =  "/^[A-Za-z ]+$/";
                Boolean validate  = true;
				
				if(!req.getParameter("email").matches(regEmail))
				{                     
					System.out.println("email dato corretto");             
				}
				else {validate=false;}
				
				if(!req.getParameter("nome").matches(regNome))
				{                     
					System.out.println("nome dato corretto");             
				}
				else {validate=false;}
				
				if(!req.getParameter("cognome").matches(regCognome))
				{                     
					System.out.println("cognome dato corretto");             
				}
				else {validate=false;}
				
				if(!req.getParameter("password").matches(regPassword)  && pass.length() >= 7 && pass.length() <= 12)  
				{   
					System.out.println("password dato corretto");                
				}
				else {validate=false;}
				
				if( ! pass.equals(pass2)){

					getServletContext().setAttribute("errorPass",  "errorPass");

					resp.sendRedirect("jsp/Registrazione.jsp");
					
					return;
				}
					
				
				if(validate==true) {
	                  System.out.println("tutti i campi sono giusti");
	              }else {
	                  RequestDispatcher view = req.getRequestDispatcher("Errore.jsp");
	                  HttpSession currentSession = req.getSession();
	                  currentSession.setAttribute("error", "error");
	                  view.forward(req,resp);
	                    return;
	              }
				
				//se tutti i contorlli sono andati a buon fine profo ad effettuare il sigin

				
				
				Utente verifica =(Utente) model.retriveUtenteByMail(email);
				if( verifica != null) {

					getServletContext().setAttribute("errorEmail",  "errorEmail");

					resp.sendRedirect("jsp/Signup.jsp");
					
					return;
				}else {
					Utente user = new Utente();
					user.setEmail(email);
					user.setPass(pass);
					user.setNome(nome);
					user.setCongome(cognome);
					model.addUtente(user);
					
					
					resp.sendRedirect("jsp/Signin.jsp");
				
					
					return;
					
				}
			}
			else {
					if(action.equals("modProfilo")) 
					{
						Utente u = new Utente();
						u.setCongome( req.getParameter("cognome"));
						u.setNome( req.getParameter("nome"));
						u.setPass( req.getParameter("pass"));
						u.setEmail( req.getParameter("email"));
						
						model.modificaUtente(u);
						Utente utente = model.retriveUtenteByMail(req.getParameter("email"));
						HttpSession session = req.getSession();
						session.removeAttribute("user");
						session.setAttribute("user", utente);
						resp.sendRedirect("Modificaprofilo.jsp");
						return;
					}
			}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	
			
}
