package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class UtenteModelDAO {
	
	public Utente retriveUtenteByMail(String email) {
		
		
		
		java.sql.Connection connection = null;
		Utente utente = new Utente();
		try {
			
			connection = DriverManagerConnectionPool.getConnection();
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM utente WHERE e_mail = ?");
			statement.setString(1, email);
			
			ResultSet rs = statement.executeQuery();
			
			if( rs.next())
			{
				utente.setCongome(rs.getString(1));
				utente.setNome(rs.getString(2));
				utente.setPass(rs.getString(3));
				utente.setEmail(rs.getString(4));
				utente.setAdmin(rs.getBoolean(5));
			}
			
			else utente = null;
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return utente;
		
	}
	
	
	public void addUtente(Utente u) throws SQLException {
		java.sql.Connection connection = null;
		PreparedStatement statement = null;
		try {
			connection = DriverManagerConnectionPool.getConnection();
			statement = connection.prepareStatement("INSERT INTO utente (cognome, nome, pass, e_mail) VALUES (?, ?, ?, ?)");
			
			statement.setString(1, u.getCongome());
			statement.setString(2, u.getNome());
			statement.setString(3, u.getPass());
			statement.setString(4, u.getEmail());
			
			statement.executeUpdate();

			connection.commit();
			
		}catch (Exception e) { e.printStackTrace();   }
		finally {
			try {
				if(statement != null)
					statement.close();
			
		}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			
			}
		}
			
	}
	
	
public ArrayList<Utente> retriveAllUtenti() throws SQLException {
		
		
		ArrayList<Utente> utenti = new ArrayList<>();
		java.sql.Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			
			connection = DriverManagerConnectionPool.getConnection();		
				 statement = connection.prepareStatement(" SELECT * from utente");
				ResultSet rs = statement.executeQuery();
				while(rs.next())
				{
					
					Utente utente = new Utente();
					
					utente.setCongome(rs.getString(1));
		        	utente.setNome(rs.getString(2));
		        	utente.setPass(rs.getString(3));
		        	utente.setEmail(rs.getString(4));
		        	utente.setAdmin(rs.getBoolean(5));
		        	utenti.add(utente);
						
				}
		}catch (Exception e) { e.printStackTrace();   }
		finally {
			try {
				if(statement != null)
					statement.close();
			
		}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			
			}
		}
			return utenti;
	}


	
	public void modificaUtente(Utente u) throws SQLException {
		java.sql.Connection connection = null;
		PreparedStatement statement = null;
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			 statement = connection.prepareStatement("UPDATE utente\r\n" + 
			 										"SET cognome = ?, nome = ?\r\n" + 
			 										"WHERE e_mail = ?");
			
			statement.setString(1, u.getCongome());
			statement.setString(2, u.getNome());
			statement.setString(3, u.getEmail());
			
			statement.executeUpdate();
			connection.commit();
			
		}catch (Exception e) { e.printStackTrace();   }
		finally {
			try {
				if(statement != null)
					statement.close();
			
		}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			
			}
		}
		
	
	}



	
	public void CambiaRuolo(String email,Boolean isAdmin) throws SQLException
	{
		java.sql.Connection connection = null;		
		PreparedStatement statement = null;
		
		
		try {
			
			connection = DriverManagerConnectionPool.getConnection();
			
			 statement = connection.prepareStatement("UPDATE utente\r\n" + 
													 "SET admin = ?\r\n" + 
													 "WHERE e_mail = ?");
			 statement.setBoolean(1, isAdmin);
			 statement.setString(2, email);
			
			 statement.executeUpdate();
			
			 connection.commit();
			
		}catch (Exception e) { e.printStackTrace();   }
		finally {
			try {
				if(statement != null)
					statement.close();
			
		}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			
			}
		}
		
		
	}
	
	
	
		public void eliminaUtente(String email) throws SQLException  {
		
		java.sql.Connection connection = null;
		PreparedStatement statement = null;
		try {
			connection = DriverManagerConnectionPool.getConnection();
			statement = connection.prepareStatement("DELETE FROM utente WHERE e_mail = ?");
			statement.setString(1, email);
		
			statement.executeUpdate();
			
			connection.commit();
			
		}catch (Exception e) { e.printStackTrace();   }
		finally {
			try {
				if(statement != null)
					statement.close();
			
		}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			
			}
		}
		
	}
		
		

}
