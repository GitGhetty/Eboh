jQuery(document).on('click', '.mega-dropdown', function(e) {
  e.stopPropagation()
});

 jQuery('ul.nav li.dropdown').hover(function() {
   jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn();
 }, function() {
   jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut();
 });